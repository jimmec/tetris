To run this java program, run this from a terminal:

javac Tetris.java && java Tetris


Note that you cannot run this program from within Eclipse: Tetrislib.java reads input in one character at a time from STDIN, and Eclipse's does not support keyboard input.